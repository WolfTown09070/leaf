/* for validatefqdn.c */
int is_validfqdn(const char *fqdn);
void validatefqdn(int);
