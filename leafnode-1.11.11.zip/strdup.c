#include <string.h>
#include <stdlib.h>

char *
strdup(const char *s)
{
    char *s1;
    s1 = malloc(strlen(s) + 1);
    if (s1 != NULL)
	strcpy(s1, s);		/* RATS: ignore */
    return s1;
}
