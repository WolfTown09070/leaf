#ifndef FETCHNEWS_H
#define FETCHNEWS_H

#include "leafnode.h"

void check_date(const struct server *);

#endif
