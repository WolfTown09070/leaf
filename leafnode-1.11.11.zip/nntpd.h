void dodate(void);
