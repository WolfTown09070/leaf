#include "leafnode.h"

int debug = 0;
int verbose = 0;

int main(void) {
    printf("%s\n", rfctime());
    return 0;
}
